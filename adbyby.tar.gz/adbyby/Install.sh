#!/bin/sh
rm -rf /etc/adbyby 2> /dev/null
rm -rf /etc/init.d/adbyby 2> /dev/null
rm -rf /etc/rc.d/S80adbyby 2> /dev/null
mkdir -p /etc/adbyby;
mkdir -p /etc/adbyby/doc;
mkdir -p /etc/adbyby/data;
cp -rf * /etc/adbyby
chmod a+x /etc/adbyby/adbyby;
chmod a+x /etc/adbyby/adbyby.sh;
chmod a+x /etc/adbyby/start;
chmod a+x /etc/adbyby/stop;
ln -s /etc/adbyby/adbyby.sh /etc/init.d/adbyby
ln -s /etc/adbyby/adbyby.sh /etc/rc.d/S80adbyby
echo "Done!";
exit 1

