#!/bin/sh
rm -rf /etc/adbyby 2> /dev/null
rm -rf /etc/init.d/adbyby 2> /dev/null
rm -rf /etc/rc.d/S80adbyby 2> /dev/null
mkdir -p /etc/adbyby;
mkdir -p /etc/adbyby/doc;
mkdir -p /etc/adbyby/data;
cp -rf * /etc/adbyby
chmod a+x /etc/adbyby/adbyby;
chmod a+x /etc/adbyby/adbyby.sh;
chmod a+x /etc/adbyby/start;
chmod a+x /etc/adbyby/stop;
ln -s /etc/adbyby/adbyby.sh /etc/init.d/adbyby
ln -s /etc/adbyby/adbyby.sh /etc/rc.d/S80adbyby
if [ -f /etc/crontabs/root ]; then
sed -i '/adbyby/d' /etc/crontabs/root
else
touch /etc/crontabs/root
fi
echo "30 */1 * * * root /etc/adbyby/start.sh" >/etc/crontabs/root
chmod +x /etc/crontabs/root
chmod 600 /etc/crontabs/root
echo 
echo "Done!";
exit 1

