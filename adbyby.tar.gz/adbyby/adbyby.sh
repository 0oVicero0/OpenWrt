#!/bin/sh /etc/rc.common
START=80
start() {
    echo "starting adbyby..."
    /etc/adbyby/start
}
stop() {
    echo "stopping adbyby..."
     /etc/adbyby/stop
}
